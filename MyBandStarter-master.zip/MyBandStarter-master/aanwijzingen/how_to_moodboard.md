<https://drive.google.com/file/d/0B6qLDDUVMycoelZkb1dJYXJDRVE/view>

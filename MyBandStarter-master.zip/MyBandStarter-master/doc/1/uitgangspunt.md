# Uitgangspunt
* keuze artiest, festival? etc.. 
* Wordt het fictief? 
* Ga je een bestaande site als uitgangspunt nemen?
* hoe uitgebreid wil je het maken?

##### Fase 1 Oriëntatie op het gekozen website onderwerp 
Oriëntatie op het gekozen website onderwerp en 
* zijn concurrenten; 
* de doelgroep(en)
* diensten.

Resultaat: voorbereiding op gesprek met opdrachtgever

##### Fase 2 Debriefing
Resultaat: document (eerste versie debriefing)

##### Fase 3 Advies aan opdrachtgever/docent
Naar aanleiding van eerste briefing 
Resultaat: 
Aantekeningen van het gesprek en eerste ideeën aan de hand van het  gekozen website onderwerp (deze kun je schrijven en je zet een link in github!)

##### Fase 4 Definitieve debriefing
De definitieve debriefing wordt ter goedkeuring aan de docent  
Dit proces wordt herhaald totdat de docent akkoord geeft om de opdracht uit te voeren.
Resultaat: document (definitieve debriefing met akkoord van docent)

# PLANNING MY Band in jouw totale rooster
Neem je urenschatting en zet deze uit tegen de uren in de week die je beschikbaar hebt. Om het aantal uren te vinden, kijk je op magister
Zet de onderdelen in je eigen rooster en let daarbij op deadlines. Plan niet te strak: houdt rekening met onverwachte vertragingen.
Deze planning is een levend document.
Dit is versie 0.0

##### WEEK1
|         | ma 15/5 | di 16/5 | wo 17/5 | do 18/5 | vr 19/5 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur | | | | | |  |
| 3de uur | | | | | |  |
| 4de uur | | | | | |  |
| 5de uur | | | | | |  |
| 6de uur | | | | | |  |
| 7de uur | | | | | |  |
| 8de uur | | | | | |  |

##### WEEK2
|         | ma 22/5 | di 23/5 | wo 24/5 | do 25/5 | vr 26/5 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur | | | | | |  |
| 3de uur | | | | | |  |
| 4de uur | | | | | |  |
| 5de uur | | | | | |  |
| 6de uur | | | | | |  |
| 7de uur | | | | | |  |
| 8de uur | | | | | |  |

##### WEEK3
|         | ma 29/5 | di 30/5 | wo 31/5 | do 1/6 | vr 2/6 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur | | | | | |  |
| 3de uur | | | | | |  |
| 4de uur | | | | | |  |
| 5de uur | | | | | |  |
| 6de uur | | | | | |  |
| 7de uur | | | | | |  |
| 8de uur | | | | | |  |

##### WEEK4
|         | ma 5/6 | di 6/6 | wo 7/6 | do 8/6 | vr 9/6 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur | | | | | |  |
| 3de uur | | | | | |  |
| 4de uur | | | | | |  |
| 5de uur | | | | | |  |
| 6de uur | | | | | |  |
| 7de uur | | | | | |  |
| 8de uur | | | | | |  |

##### WEEK5
|         | ma 12/6 | di 13/6 | wo 14/6 | do 15/6 | vr 16/6 | weekend |
| ------ |------ | ---- | ------ |---- |------ |---- | 
| 1ste uur | | | | | |  |
| 2de uur | | | | | |  |
| 3de uur | | | | | |  |
| 4de uur | | | | | |  |
| 5de uur | | | | | |  |
| 6de uur | | | | | |  |
| 7de uur | | | | | |  |
| 8de uur | | | | | |  |

Peer Review.
